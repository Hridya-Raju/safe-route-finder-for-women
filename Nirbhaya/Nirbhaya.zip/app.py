from flask import Flask, request, jsonify
import googlemaps
import firebase_admin
from firebase_admin import credentials, firestore, auth
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Initialize Google Maps client with your API key
gmaps = googlemaps.Client(key="AIzaSyCrfmZ1LLM5_lYTsnUTX8qmjOQfMe0dS4A")  # Replace with your actual API key

cred = credentials.Certificate("nirbhaya-90922-firebase-adminsdk-fbsvc-43d31cff0e.json")  # Make sure the filename matches!
firebase_admin.initialize_app(cred)
db = firestore.client()

@app.route('/get_safe_route', methods=['GET', 'POST'])
def get_safe_route():
    # Get origin and destination from the request
    data = request.json
    origin = data['origin']
    destination = data['destination']

    # Fetch directions using Google Maps API
    try:
        directions = gmaps.directions(origin, destination, mode="walking")
        return jsonify(directions)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/add_user", methods=["POST"])
def add_user():
    data = request.json  # Assuming request contains {"name": "Alice", "age": 25}
    doc_ref = db.collection("users").document()
    doc_ref.set(data)
    return jsonify({"message": "User added successfully!"})

@app.route("/get_users", methods=["GET"])
def get_users():
    users_ref = db.collection("users").stream()
    users = [{user.id: user.to_dict()} for user in users_ref]
    return jsonify(users)

@app.route("/register", methods=["POST"])
def register():
    data = request.json  # Expecting {"email": "user@example.com", "password": "password123"}
    user = auth.create_user(email=data["email"], password=data["password"])
    return jsonify({"message": "User created", "uid": user.uid})

@app.route("/login", methods=["POST"])
def login():
    data = request.json  # Expecting {"email": "user@example.com", "password": "password123"}
    user = auth.get_user_by_email(data["email"])
    return jsonify({"message": "User found", "uid": user.uid})

# Route to report unsafe areas
@app.route('/report_unsafe_area', methods=['POST'])
def report_unsafe_area():
    data = request.json
    location = data['location']
    user_id = data.get('user_id', 'anonymous')  # Optional: Track user who reported

    try:
        # Store the report in Firestore
        report_ref = db.collection('unsafe_areas').document()
        report_ref.set({
            'location': location,
            'user_id': user_id,
            'timestamp': firestore.SERVER_TIMESTAMP
        })
        return jsonify({"status": "success", "report_id": report_ref.id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Route to fetch reported unsafe areas
@app.route('/get_unsafe_areas', methods=['GET'])
def get_unsafe_areas():
    try:
        # Fetch all reported unsafe areas from Firestore
        unsafe_areas = []
        reports_ref = db.collection('unsafe_areas').stream()
        for report in reports_ref:
            unsafe_areas.append(report.to_dict())
        return jsonify(unsafe_areas)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
if __name__ == "__main__":
    app.run(debug=True)


